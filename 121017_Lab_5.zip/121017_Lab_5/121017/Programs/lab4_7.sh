read n
ls $n*

