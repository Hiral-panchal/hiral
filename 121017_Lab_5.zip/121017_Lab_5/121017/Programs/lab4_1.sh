rev<<<$1
