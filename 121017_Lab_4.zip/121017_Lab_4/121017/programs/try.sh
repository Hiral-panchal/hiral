Hello
where are you?
I am waitting for you.
please come here.
I am coming.
