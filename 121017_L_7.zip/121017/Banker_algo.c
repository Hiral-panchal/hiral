			#include<stdio.h>
			void main()
			 {
			   int p,r,i,j,inst,k=0,c1=0,c2=0;
			 
			   printf("Enter No. of process:-\n");
			
			   scanf("%d",&p);                            
			 
			   printf("Enter No. of resources:-\n");
			 
			   scanf("%d",&r);                     
			 
			   int avail[r],max[p][r],allot[p][r],need[p][r],completed[p];
			 
			   for(i=0;i<p;i++)
			   completed[i]=0;                             
			 
			   printf("Enter No. of Available is:\n");
			 
			   for(i=0;i<r;i++)
			    {
			 
			     scanf("%d",&inst);
			 
			     avail[i]=inst;                        
			    }
			 
			   printf("Enter Max Matrix:\n");
			 
			    for(i=0;i<p;i++)
			     {
				printf("\n p %d:",i);
			 
				for(j=0;j<r;j++)
				 {
				    scanf("%d",&inst);
			 
				    max[i][j]=inst;              
				 }
			     }    
			    printf("Enter Allocated Matrix :\n");
			 
			     for(i=0;i<p;i++)
			     {
				printf("\n p %d:",i);
			 
				for(j=0;j<r;j++)
				 {
				    scanf("%d",&inst);
			 
				    allot[i][j]=inst;
			 
				    need[i][j]=max[i][j]-allot[i][j];       
				 } 
			    }
			    
			    printf("\n Max matrix:\tAllocation matrix:\n");

            for(i = 0; i < p; i++)
            {
                for( j = 0; j < r; j++)
                    printf("%d ", max[i][j]);
                printf("\t\t");
                for( j = 0; j < r; j++)
                    printf("%d ", allot[i][j]);
                printf("\n");
            }

				printf("\n Need Matrix:\n");
				  for(i=0;i<p;i++)
					{
			for(j = 0; j < r; j++)
			{
			    
			    
			    printf("%d ", need[i][j]);
			    printf("\t");
			}
			    printf("\n");
			    
	
			}


			    printf("\n\t Safe Sequence is:- \t");
			 
			    while(c1!=p)
			    {
			    c2=c1;
			    for(i=0;i<p;i++)
			     {
			 
			       for(j=0;j<r;j++)
				{
				    if(need[i][j]<=avail[j])
				      {
					 k++;
				      }  
				     
				}    
				if(k==r && completed[i]==0 )
				 {
				   printf("%d\t",i);
			 
				   completed[i]=1;
			 
				   for(j=0;j<r;j++)
				     {
				     
				       avail[j]=avail[j]+allot[i][j];
				    
				     } 
				     c1++;
				      
				 }
				 k=0;
				 
			       }
			  
				 if(c1==c2)
				 {
				 printf("Stop.After this...Deadlock \n");
			 
				 break;
			       } 
			 }
			   
			}            
